from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
for name, revision in [('core-storage',27),('calendar',20),('mail-ui',25),('cli',20),('quality',23)]:
    path = ROOT/'docs/contracts'/f'{name}.md'
    lines = path.read_text(encoding='utf-8').splitlines()
    index = next(i for i,line in enumerate(lines) if line.startswith('State: Draft · Revision:'))
    lines[index] = f'State: Draft · Revision: {revision} · Updated: 2026-09-14 · Implementation: D038/D039 Windows feedback verification is active under Core 27/Calendar 20/Mail UI 25/CLI 20/Platform 14/Quality 23/schema 20. Gmail 12/Search 5, fixtures 0/3/protocol 1 unchanged. Package01 at 513a5af passes its source-specific relocated checks; the final cached Calendar search, native and performance checks are in progress. Actual-account acceptance and whole readiness remain open.'
    path.write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('Current contract status now identifies D039 without changing prior evidence.')
