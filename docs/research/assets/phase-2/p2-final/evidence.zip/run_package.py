"""Run the existing Windows package command with immutable numbered evidence."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import dev


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def sources():
    paths = [ROOT / p for p in ("CMakeLists.txt", "CMakePresets.json", "Cargo.toml", "Cargo.lock", "rust-toolchain.toml", "docs/build-development.md")]
    for directory in ("gui", "crates", "fixtures", "scripts"):
        paths.extend(p for p in (ROOT / directory).rglob("*") if p.is_file() and "__pycache__" not in p.parts)
    return {p.relative_to(ROOT).as_posix(): digest(p) for p in sorted(set(paths))}


def identity(path):
    return {"path": str(path), "size": path.stat().st_size, "sha256": digest(path)}


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--attempt", type=int, required=True)
parser.add_argument("--commit", required=True)
args = parser.parse_args()
if not 1 <= args.attempt <= 99:
    parser.error("Use a bounded numbered attempt")
if dev.HOST != "Windows":
    raise SystemExit("This evidence runner is Windows-only")
stem = f"package-windows-{args.attempt:02}"
files = {key: OUT / (stem + suffix) for key, suffix in {
    "log": ".log", "result": ".result.json", "sources": ".source.json",
    "inventory": ".inventory.json", "runtime": ".runtime.log", "previous_runtime": ".previous-runtime.log"}.items()}
if any(path.exists() for path in files.values()):
    raise SystemExit("Never overwrite a package attempt")
commit = git("rev-parse", "HEAD")
if commit != args.commit or git("status", "--porcelain"):
    raise SystemExit("Package requires the exact committed clean source selected by the parent")
stage = ROOT.resolve() / "dist/windows-amd64"
if stage.resolve() != stage:
    raise SystemExit("Resolved package stage is outside the expected workspace dist path")
archive = ROOT / "dist/fuckmail-windows-amd64.zip"
runtime = ROOT / "build/verification/package-runtime.log"
if runtime.is_file():
    shutil.copy2(runtime, files["previous_runtime"])
before = sources()
write(files["sources"], before)
command = [str(dev.PYTHON), str(ROOT / "scripts/dev.py"), "package", "--preset", "release"]
configure_command = [str(dev.managed_tool("cmake")), "--preset", "release",
                     "-DCMAKE_MAKE_PROGRAM=" + str(dev.managed_tool("ninja"))]
started = time.monotonic()
started_at = datetime.now(timezone.utc)
code, error = -1, None
archive_identity, executables = None, {}
try:
    with files["log"].open("x", encoding="utf-8", newline="\n") as output:
        for invocation in (configure_command, command):
            output.write("+ " + subprocess.list2cmdline(invocation) + "\n")
            output.flush()
            code = subprocess.run(invocation, cwd=ROOT, env=dev.environment(), stdin=subprocess.DEVNULL,
                                  stdout=output, stderr=subprocess.STDOUT).returncode
            if code:
                break
    if code:
        raise RuntimeError(f"Existing package command exited {code}")
    if not archive.is_file() or archive.stat().st_mtime < started_at.timestamp():
        raise RuntimeError("Package command did not produce a fresh archive")
    manifest = json.loads((stage / "build-manifest.json").read_text(encoding="utf-8"))
    if manifest.get("source") != commit or manifest.get("source_dirty") is not False:
        raise RuntimeError("Packaged manifest is not bound to the selected clean commit")
    package_files = {p.relative_to(stage).as_posix(): {"size": p.stat().st_size, "sha256": digest(p)}
                     for p in sorted(stage.rglob("*")) if p.is_file()}
    with zipfile.ZipFile(archive) as zipped:
        members = [entry for entry in zipped.infolist() if not entry.is_dir()]
        if len(members) != len(package_files) or len({entry.filename for entry in members}) != len(members):
            raise RuntimeError("Archive file set differs from the verified package")
        for entry in members:
            prefix = "windows-amd64/"
            if not entry.filename.startswith(prefix):
                raise RuntimeError("Archive contains a file outside its package directory")
            record = package_files.get(entry.filename[len(prefix):])
            if record is None or record["size"] != entry.file_size or record["sha256"] != hashlib.sha256(zipped.read(entry)).hexdigest():
                raise RuntimeError("Archive contents differ from the verified package")
    write(files["inventory"], package_files)
    executables = {name: identity(stage / "bin" / name) for name in ("fuckmail-gui.exe", "fm-engine.exe", "fm.exe")}
    archive_identity = identity(archive)
    if "Relocated package passed: SDK-free GUI smoke/self-test" not in files["log"].read_text(encoding="utf-8", errors="replace"):
        raise RuntimeError("Missing existing relocated verification completion")
except Exception as exc:
    error = f"{type(exc).__name__}: {exc}"
finally:
    if runtime.is_file() and runtime.stat().st_mtime >= started_at.timestamp():
        shutil.copy2(runtime, files["runtime"])
    after = sources()
    changed = sorted(name for name in before.keys() | after.keys() if before.get(name) != after.get(name))
    clean_after = git("rev-parse", "HEAD") == commit and not git("status", "--porcelain")
    result = {"status": "passed" if code == 0 and error is None and not changed and clean_after else "failed",
              "exit_code": code, "error": error, "source_commit": commit, "source_count": len(before),
              "source_changes": changed, "clean_commit_unchanged": clean_after,
              "started_at_utc": started_at.isoformat(), "finished_at_utc": datetime.now(timezone.utc).isoformat(),
              "elapsed_seconds": time.monotonic() - started, "command": command, "cache_tool_repair": configure_command,
              "stage": str(stage), "build_targets": ["fm-client-runtime"], "package_verification_unchanged": True,
              "executables": executables, "archive": archive_identity,
              "artifacts_sha256": {path.name: digest(path) for key, path in files.items() if key != "result" and path.is_file()}}
    write(files["result"], result)
    print(json.dumps(result), flush=True)
raise SystemExit(0 if result["status"] == "passed" else 1)
