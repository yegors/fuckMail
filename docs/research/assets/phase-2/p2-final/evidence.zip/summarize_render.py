import argparse
import hashlib
import json
from pathlib import Path

base = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument('--attempt', default='01')
p.add_argument('--source-commit', default='61a212aee58592ddbd018c4f87061508e178f2ee')
p.add_argument('--package', default='Package02')
args = p.parse_args()
output = base / f'render-visual-review-{args.attempt}.json'
if output.exists():
    raise RuntimeError('Preserve existing review')
names = [
    'resize-graphite-01.gui-captures/mail-resize-06.png',
    'resize-paper-01.gui-captures/calendar-resize-06.png',
    'resize-harbour-01.gui-captures/mail-settled-1.png',
    'resize-paper-01.gui-captures/mail-resize-06.png',
    'resize-harbour-01.gui-captures/calendar-resize-06.png',
    'resize-graphite-01.gui-captures/calendar-settled-1.png',
]
names = [name.replace('-01.', f'-{args.attempt}.') for name in names]
record = {
    'scope': 'Root inspected these six saved native images. Static captures do not establish physical scanout or absence of every transient frame defect. Geometry review separately covers all 90 saved frames.',
    'source_commit': args.source_commit,
    'package': args.package,
    'observations': [
        'Mail actions align to the right, primary actions have readable text, and the central rule remains crisp in the inspected images.',
        'Calendar grid and day boundaries are aligned; dense event titles elide within their cells. No displaced or double vertical border is visible in the inspected images.',
        'Narrow header account tabs use their clipped scrollable area; the reference primary actions remain visible.',
        'This synthetic resize scenario does not by itself prove real Send behavior or replace the separate exact large-mailbox navigation checks.',
    ],
    'images': [{'file': name, 'sha256': hashlib.sha256((base / name).read_bytes()).hexdigest()} for name in names],
}
output.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
data = json.loads((base / f'render-review-{args.attempt}.json').read_text())
for theme, value in data['themes'].items():
    counts = {n for row in value['long_mail_vertical_rules'] for n in row['matching_fill_pixels_per_sampled_row']}
    print(theme, 'matching fill pixels per sampled row:', sorted(counts))
    resize = json.loads((base / f'resize-{theme}-{args.attempt}.gui.json').read_text())
    print('resize top-level fields:', list(resize))
    for key in ('workspaces', 'classes', 'measurements'):
        if key in resize:
            print(key, json.dumps(resize[key])[:3000])
