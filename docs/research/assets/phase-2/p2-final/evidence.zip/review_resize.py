"""Read native resize capture metadata without altering images or test results."""
import argparse
import json
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--prefix', required=True)
p.add_argument('--output', required=True, type=Path)
p.add_argument('--attempt', default='01')
args = p.parse_args()
if args.output.exists(): raise RuntimeError('Do not overwrite render review evidence')
result = {'scope': 'Saved frame geometry and pixel samples only; image review and physical scanout remain separate.', 'themes': {}}
for theme in ('graphite', 'paper', 'harbour'):
    path = Path(f'{args.prefix}{theme}-{args.attempt}.gui.json')
    data = json.loads(path.read_text(encoding='utf-8'))
    aligned, misaligned, colors, vertical = 0, [], {}, []
    for capture in data['captures']:
        for line in capture['lines']:
            key = (capture['workspace'], line['path'])
            colors.setdefault(key, set()).add(line['fill_argb'])
            x,y,w,h = line['device_rect']
            is_vertical = abs(w-1) < 1e-5 and h > 5
            is_horizontal = abs(h-1) < 1e-5 and w > 5
            if is_vertical or is_horizontal:
                origin = x if is_vertical else y
                if abs(origin-round(origin)) > 1e-5:
                    misaligned.append({'capture':Path(capture['path']).name,'path':line['path'],'rect':line['device_rect']})
                else: aligned += 1
            if capture['workspace'] == 'mail' and is_vertical and h > 300:
                samples = {}
                for sample in line['samples']:
                    if sample['argb'] == line['fill_argb']:
                        samples.setdefault(sample['y'],set()).add(sample['x'])
                vertical.append({'capture':Path(capture['path']).name,'path':line['path'],'device_rect':line['device_rect'],
                    'fill_argb':line['fill_argb'],'matching_fill_pixels_per_sampled_row':[len(xs) for xs in samples.values()]})
    returned = []
    for workspace in ('mail','calendar'):
        captures = [c for c in data['captures'] if c['workspace'] == workspace and c['kind'] == 'settled_A_B_A']
        if len(captures) != 3: raise RuntimeError('Missing settled A/B/A capture triplet')
        first,last = ({line['path']:line for line in c['lines']} for c in (captures[0],captures[2]))
        common = first.keys() & last.keys()
        differences = [key for key in common if first[key]['fill_argb'] != last[key]['fill_argb']
            or any(abs(a-b)>1e-5 for a,b in zip(first[key]['device_rect'],last[key]['device_rect']))]
        returned.append({'workspace':workspace,'common_paths':len(common),'differences':differences,
            'first_only':sorted(first.keys()-last.keys()),'last_only':sorted(last.keys()-first.keys())})
    result['themes'][theme] = {'captures':len(data['captures']),'aligned_one_pixel_rules':aligned,
        'misaligned_one_pixel_rules':misaligned,
        'changing_fill_paths':[{'workspace':key[0],'path':key[1],'colors':sorted(values)} for key,values in colors.items() if len(values)>1],
        'returned_geometry':returned,'long_mail_vertical_rules':vertical,
        'calendar_scroll_passed':data['calendar_scroll_exercise']['passed']}
args.output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
for theme,record in result['themes'].items():
    print(theme,json.dumps({key:value for key,value in record.items() if key != 'long_mail_vertical_rules'}))
