import hashlib,json,subprocess,sys,time
from pathlib import Path
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));from scripts import dev
mode,attempt=sys.argv[1:3];base=ROOT/'build/verification/p2-final'/f'calendar-search-{mode}-{attempt}'
paths=[p for p in (ROOT/'gui').rglob('*') if p.is_file()]+[ROOT/'CMakeLists.txt']
def stamp():return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
for suffix in ('.log','.source.json','.result.json'):
 if base.with_suffix(suffix).exists():raise RuntimeError('Evidence already exists')
before=stamp();base.with_suffix('.source.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
build=ROOT/'build/p2-05b3a-gui-dev';binary=build/'gui-calendar-search-test.exe';env=dev.environment();env['QT_FORCE_STDERR_LOGGING']='1'
if mode=='build':cmd=[str(dev.managed_tool('cmake')),'--build',str(build),'--target','gui-calendar-search-test','--parallel','8']
else:
 env['QT_QPA_PLATFORM']='offscreen';env['QT_QUICK_BACKEND']='software';env['QT_D3D_NO_VBLANK_THREAD']='1'
 cmd=[str(binary)];captures=ROOT/'build/verification/p2-final'/f'calendar-search-visual-{attempt}'
 if captures.exists():raise RuntimeError('Captures already exist')
 env['FM_CALENDAR_SEARCH_CAPTURE_DIR']=str(captures)
start=time.monotonic()
with base.with_suffix('.log').open('x',encoding='utf-8') as log:r=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
after=stamp();result={'command':cmd,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'source_count':len(before),'source_changes':[k for k,v in before.items() if after.get(k)!=v],'binary':{'path':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()} if binary.exists() else None}
base.with_suffix('.result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result));print(base.with_suffix('.log').read_text(encoding='utf-8',errors='replace')[-7000:]);sys.exit(r.returncode)
