"""Exercise existing prebuilt Windows tests with generated local data only."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
stem = "windows-readiness-01"
paths = {name: OUT / (stem + suffix) for name, suffix in {
    "log": ".log", "source": ".source.json", "result": ".result.json"}.items()}
if any(p.exists() for p in paths.values()):
    raise SystemExit("Refusing to overwrite readiness evidence")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source():
    files = [ROOT / p for p in ("Cargo.toml", "Cargo.lock", "rust-toolchain.toml")]
    for name in ("fm-google", "fm-ipc"):
        files.extend(p for p in (ROOT / "crates" / name).rglob("*") if p.is_file())
    return {p.relative_to(ROOT).as_posix(): sha(p) for p in sorted(files)}


google = ROOT / "target/debug/deps/fm_google-2a69ce3ca8eb9fe0.exe"
ipc = ROOT / "target/debug/deps/fm_ipc-62aad3fa7bef9bf0.exe"
checks = [(google, "desktop_auth::tests::native_vault_synthetic_roundtrip_and_cleanup", True),
          (ipc, "windows::tests::private_file_has_explicit_process_user_owner", False),
          (ipc, "tests::discovery_roundtrip_and_profile_permissions", False)]
before = source()
paths["source"].write_text(json.dumps(before, indent=2) + "\n", encoding="utf-8")
binary_before = {p.relative_to(ROOT).as_posix(): {"sha256": sha(p), "size": p.stat().st_size} for p in (google, ipc)}
started = time.monotonic()
results = []
with paths["log"].open("x", encoding="utf-8", newline="\n") as stream:
    for executable, test, ignored in checks:
        command = [str(executable), "--exact", test, "--test-threads=1"] + (["--ignored"] if ignored else [])
        stream.write("+ " + subprocess.list2cmdline(command) + "\n")
        stream.flush()
        began = time.monotonic()
        completed = subprocess.run(command, cwd=ROOT, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, text=True, timeout=30)
        stream.write(completed.stdout)
        stream.flush()
        passed = completed.returncode == 0 and re.search(r"test result: ok\. 1 passed; 0 failed; 0 ignored;", completed.stdout) is not None
        results.append({"name": test, "status": "passed" if passed else "failed", "exit_code": completed.returncode,
                        "elapsed_seconds": time.monotonic() - began, "command": command})
        if not passed:
            break
after = source()
changed = sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))
binary_after = {p.relative_to(ROOT).as_posix(): {"sha256": sha(p), "size": p.stat().st_size} for p in (google, ipc)}
result = {"status": "passed" if len(results) == 3 and all(r["status"] == "passed" for r in results) and not changed and binary_before == binary_after else "failed",
          "scope": "Existing prebuilt tests; generated isolated native credential entry and disposable profile only. No Cargo, real Google, existing credential enumeration, or real profile.",
          "elapsed_seconds": time.monotonic() - started, "checks": results, "executables": binary_before,
          "executables_unchanged": binary_before == binary_after, "source_count": len(before), "source_changes": changed,
          "source_sha256": sha(paths["source"]), "log_sha256": sha(paths["log"]),
          "limitations": ["Native vault check covers the current unlocked user session, not locked-vault behavior or actual Google refresh.",
                          "Windows permission smoke proves current-user ownership, exclusive discovery creation and roundtrip; it is not another-user access testing or disk-encryption verification."]}
paths["result"].write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result))
raise SystemExit(0 if result["status"] == "passed" else 1)
