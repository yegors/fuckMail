from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
boundary = 'Core 27/Calendar 20/Mail UI 25/CLI 20/Quality 23; schema 20, Platform 14/Gmail 12/Search 5, fixtures 0/3 and protocol 1 unchanged'
details = {
 'core-storage': (27, 'D039 adds read-only calendar_search through the existing permitted combined projection. It creates no index, schema, receipt or provider work. The explicit 1–42-day range and selected-calendar semantics remain unchanged. Query text is at most 512 UTF-8 bytes and 32 whitespace-separated case-insensitive AND substring terms over permitted title, organizer, attendees, location and description. Busy-only rows are excluded; split-day rows deduplicate by account/calendar/occurrence identity. Return at most 100 results with has_more plus inherited range, revision and coverage. Existing projection limits remain explicit.'),
 'calendar': (20, 'D039 implements Find an event as cached search in an explicit displayed date range of 1–42 days. calendar_search accepts query/from/to, optional calendars and limit 1–100, preserving the calendar_combined visibility, permissions, privacy, range and projection bounds. Match at most 32 case-insensitive whitespace-separated AND substrings across title, organizer/attendee display names and addresses, location and description; query is nonblank and at most 512 UTF-8 bytes. Search only permitted projected fields and exclude busy-only rows. Deduplicate the same occurrence across day segments. The response retains events/from/to/time_zone/revision/coverage/continuation:null and adds query, limit, has_more and total for the returned rows. No all-history or live-search claim follows from a bounded cached result.'),
 'mail-ui': (25, 'D039 reuses the top search field contextually for Calendar with a separate query from Mail. A matching themed popup shows the current searched date range, coverage and bounded results; calendar visibility and the combined/account toggle constrain the shared query. Selecting a result navigates to its occurrence and opens details only after a fresh matching identity is available. Fence late responses across query/range/selection/account/lifecycle changes. Mail search behavior and timing targets remain unchanged.'),
 'cli': (20, 'D039 adds fm calendar search QUERY --from YYYY-MM-DD --to YYYY-MM-DD [--limit 1..100] against the global calendar_search query and selected-calendar preferences. It returns the same permitted occurrences, date range, coverage and has_more as the GUI, without provider acquisition or mutation. The general call interface can provide explicit calendar identities.'),
 'quality': (23, 'D039 acceptance covers cached Calendar search text fields, partial grants/privacy, selected visibility, recurrence/exception and multi-day identity, bounds, no mutation/provider work, CLI routing and native query/selection/stale-response behavior. Rebuild affected targets and rerun focused tests, then package the final source and measure the existing navigation/search/resize targets. Earlier full workspace/native/package observations retain their exact source limits; do not relabel them as rerun on a later source.'),
}
for name, (revision, detail) in details.items():
    path = ROOT / 'docs/contracts' / f'{name}.md'
    text = path.read_text(encoding='utf-8')
    import re
    text, count = re.subn(r'Revision: \d+', f'Revision: {revision}', text, count=1)
    if count != 1: raise RuntimeError(f'Missing revision: {name}')
    lines = text.splitlines()
    at = next(i for i,line in enumerate(lines) if 'Revision:' in line) + 1
    lines[at:at] = ['', detail + ' Consumers: ' + boundary + '.']
    path.write_text('\n'.join(lines)+'\n', encoding='utf-8')
decision = '''
## 2026-09-14T07:38:00Z — D039: close the cached Calendar search gap before final feedback packaging

The final review of D038 finds the already-required Find an event workflow missing. Complete it under the founder's active spec-complete request, using the existing Calendar projection and top search field. Do not add a second index or migration. This implementation choice consumes Core 27/Calendar 20/Mail UI 25/CLI 20/Quality 23; schema 20, Platform 14/Gmail 12/Search 5, fixtures 0/3 and protocol 1 remain unchanged.

Search an explicit displayed range of 1–42 civil days and selected calendars, with bounded case-insensitive AND substring matching over permitted title, organizer, attendees, location and description. Exclude busy-only data and deduplicate split-day segments by exact occurrence identity. Return at most 100 rows with coverage and has_more; no all-history or remote-search claim. GUI and CLI share calendar_search; native selection navigates by a fresh matching occurrence and late callbacks cannot publish across changed query/range/visibility/account/lifecycle.

Evidence is focused Core/CLI/native behavior, unchanged provider/privacy semantics, rebuilt runtime and final package/performance checks. Package01 at 513a5af has already passed its SDK-free relocated tests and remains an earlier source-bound observation. No real-account action is added. Preserve earlier failures and the single final evidence report.
'''
with (ROOT/'docs/decisions.md').open('a',encoding='utf-8') as output: output.write(decision)
for path in ['docs/status.md','docs/plans/phase-2.md','docs/development-plan.md','README.md']:
    file = ROOT/path
    text = file.read_text(encoding='utf-8')
    first, rest = text.split('\n',1)
    file.write_text(first+'\n\n**D039 final gap:** implement required cached Calendar search through the existing shared projection before final packaging. '+boundary+'. D038 Package01 passed on its own source; final search/native/performance evidence is pending.\n'+rest,encoding='utf-8')
path = ROOT/'AGENTS.md'
text = path.read_text(encoding='utf-8')
text = text.replace('## Current stage rules\n','## Current stage rules\n\n- D039 closes the required cached Calendar search gap using Core 27/Calendar 20/Mail UI 25/CLI 20/Quality 23; schema 20 and other revisions remain unchanged. Reuse the permitted combined projection, explicit 1–42-day range and current search box; no new index or schema. Package01 at 513a5af passes its SDK-free Windows checks but predates this final addition. Preserve source-specific evidence and finish final package/performance checks.\n',1)
path.write_text(text,encoding='utf-8')
print('Declared D039 boundary and focused acceptance.')
