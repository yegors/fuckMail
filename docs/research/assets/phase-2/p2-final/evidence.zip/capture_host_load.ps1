param([Parameter(Mandatory=$true)][string]$Report)
$ErrorActionPreference = 'Stop'
if (Test-Path -LiteralPath $Report) { throw 'Choose a new evidence path.' }
$taskSamples = @()
$taskErrors = @()
try {
    $taskCounters = Get-Counter -Counter '\Processor(_Total)\% Processor Time', '\GPU Engine(*)\Utilization Percentage' -SampleInterval 1 -MaxSamples 5
    foreach ($taskSample in $taskCounters) {
        $taskCpu = @($taskSample.CounterSamples | Where-Object { $_.Path -like '*processor(_total)*' })
        $taskGpu = @($taskSample.CounterSamples | Where-Object { $_.Path -like '*gpu engine*' -and $_.Status -eq 0 })
        $taskSamples += [ordered]@{
            timestamp = $taskSample.Timestamp.ToUniversalTime().ToString('o')
            cpu_percent = if ($taskCpu.Count) { $taskCpu[0].CookedValue } else { $null }
            gpu_engine_max_percent = if ($taskGpu.Count) { ($taskGpu | Measure-Object CookedValue -Maximum).Maximum } else { $null }
            gpu_sample_count = $taskGpu.Count
        }
    }
} catch { $taskErrors += $_.Exception.Message }
$taskRecord = [ordered]@{
    scope = 'Five ambient Windows samples before measurement; no apps closed or host settings changed. GPU value is the highest process-engine counter, not total adapter utilization.'
    samples = $taskSamples
    errors = $taskErrors
}
$taskRecord | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $Report -Encoding utf8
$taskRecord | ConvertTo-Json -Depth 6
