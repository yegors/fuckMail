import hashlib, json, os, subprocess, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from scripts import dev
mode, attempt = sys.argv[1:3]
base = Path(__file__).parent / ('gui-notifications-' + mode + '-' + attempt)
for suffix in ['.log', '.source.json', '.result.json']:
    if base.with_suffix(suffix).exists(): raise RuntimeError('Refuse existing evidence')
paths = [ROOT/'CMakeLists.txt'] + [p for p in (ROOT/'gui').iterdir() if p.is_file()]
inputs = lambda: {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
before = inputs()
base.with_suffix('.source.json').write_text(json.dumps(before, indent=2)+'\n',encoding='utf-8')
env = dev.environment()
env.update(QT_QPA_PLATFORM='offscreen',QT_QUICK_BACKEND='software',QT_FORCE_STDERR_LOGGING='1')
if os.name == 'nt': env['QT_QPA_FONTDIR'] = str(Path(os.environ['SystemRoot'])/'Fonts')
build = ROOT/'build/p2-05b3a-gui-dev'
cmake = str(dev.VENV_BIN/('cmake'+dev.SUFFIX))
commands = [[cmake,'-S',str(ROOT),'-B',str(build)], [cmake,'--build',str(build),'--target','gui-notification-backend-test','--parallel','2']] if mode=='build' else [[str(build/'gui-notification-backend-test.exe')]]
start = time.monotonic(); code = -1; error = None
with base.with_suffix('.log').open('x',encoding='utf-8') as log:
    try:
        for command in commands:
            code = subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600 if mode=='build' else 30).returncode
            if code: break
    except Exception as exc: error = str(exc)
after = inputs()
report = dict(commands=commands,exit_code=code,error=error,elapsed_seconds=time.monotonic()-start,source_count=len(before),source_changes=[p for p in before if before[p]!=after.get(p)])
binary = build/'gui-notification-backend-test.exe'
if binary.exists(): report['binary'] = dict(path=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
base.with_suffix('.result.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report)); print(base.with_suffix('.log').read_text(encoding='utf-8',errors='replace')[-8000:])
sys.exit(0 if code==0 and error is None else 1)
