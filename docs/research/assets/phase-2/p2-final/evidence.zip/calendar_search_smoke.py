"""Actual ordinary Release CLI search, with generated local content only."""
import hashlib
from contextlib import closing
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "scripts"))
from verify_google_navigation import source_manifest

report = Path(sys.argv[1]).resolve()
assert not report.exists(), "Use a new numbered report"
cli, engine = [ROOT / "target/release" / name for name in ("fm.exe", "fm-engine.exe")]
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
inputs = lambda: {k:v for k,v in source_manifest().items() if k.startswith("crates/") or k in ("Cargo.toml", "Cargo.lock", "rust-toolchain.toml")}
before = inputs()
result = {"result":"failed", "scenario":"ordinary-cli-cached-calendar-search", "executables":{p.name:{"path":str(p),"sha256":sha(p)} for p in (cli,engine)}, "commands":[], "source_inputs":before,
          "limitations":["Generated synthetic authored events and an empty live profile; no Google/vault/network or performance acceptance."]}
started = time.monotonic()
def snapshot(profile):
    with closing(sqlite3.connect((profile / "store.sqlite3").as_uri()+"?mode=ro",uri=True)) as db:
        return {name:db.execute("SELECT * FROM "+name+" ORDER BY rowid").fetchall() for name in ("calendar_sources", "calendar_write_operations", "accounts", "meta")}
try:
    with tempfile.TemporaryDirectory(prefix="fuckmail-calendar-search-") as directory:
        base = Path(directory)
        def call(tail, account=None, live=False):
            profile = base / ("live" if live else "demo")
            command = [str(cli),"--profile",str(profile),"--engine",str(engine),"--json"]
            if not live: command.append("--demo-profile")
            if account: command += ["--account",account]
            command += tail
            output = subprocess.run(command,cwd=ROOT,capture_output=True,text=True,timeout=30)
            value = json.loads(output.stdout)
            result["commands"].append({"args":tail,"account":account,"live":live,"exit_code":output.returncode,"reply":value})
            assert output.returncode == 0 and value["ok"] is True, output.stderr or value
            return value["result"]
        for account in ("personal","windscribe"):
            params = {"request_id":"search-create-"+account,"kind":"create","calendar_id":"primary","fields":{"title":"Cross Account Needle","start":"2026-09-14","end":"2026-09-17","all_day":True,"time_zone":"America/Toronto","location":"Blue Room","description":"Distinctive agenda","conference_url":"https://example.test/join","attendees":["guest@example.test"]}}
            path = base / (account+".json"); path.write_text(json.dumps(params),encoding="utf-8")
            call(["calendar-write","--params-file",str(path)],account)
        profile = base / "demo"
        cached_before = snapshot(profile)
        args = ["calendar","search","NEEDLE blue guest@","--from","2026-09-14","--to","2026-09-17"]
        data = call(args)
        assert data["total"] == 2 and data["has_more"] is False
        assert {v["account"] for v in data["events"]} == {"personal","windscribe"}
        assert len({v["id"] for v in data["events"]}) == 2
        limited = call(args+["--limit","1"])
        assert limited["total"] == 1 and limited["has_more"] is True
        assert limited["coverage"] == data["coverage"]
        assert snapshot(profile) == cached_before
        empty = call(["status"],live=True)
        assert empty["profile_kind"] == "live" and empty["fixture_revision"] == 0
        empty_before = snapshot(base/"live")
        response = call(args,live=True)
        assert response["total"] == 0 and response["coverage"]["complete"] is False
        assert snapshot(base/"live") == empty_before
        result["ordinary_global_cli_routing"] = True
        result["multiday_distinct_accounts"] = 2
        result["read_only_snapshots_unchanged"] = True
        deadline = time.monotonic()+10
        while any((base/name/"engine.json").exists() for name in ("demo","live")):
            assert time.monotonic()<deadline, "Final CLI owner did not drain its engine"
            time.sleep(.05)
        result["final_owners_drained"] = True
    assert inputs() == before, "Compiled source changed"
    assert all(sha(p) == result["executables"][p.name]["sha256"] for p in (cli,engine))
    result["result"] = "passed"
except Exception as error:
    result["error"] = str(error)
result["elapsed_seconds"] = time.monotonic()-started
result["helper_sha256"] = sha(Path(__file__))
with report.open("x",encoding="utf-8") as stream: json.dump(result,stream,indent=2); stream.write("\n")
print(json.dumps({k:result[k] for k in ("result","elapsed_seconds","error") if k in result}))
raise SystemExit(0 if result["result"] == "passed" else 1)
