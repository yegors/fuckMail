"""Preserve one compact archive of this run's generated verification evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
p = argparse.ArgumentParser()
p.add_argument('--output', required=True, type=Path)
p.add_argument('--source-commit', required=True)
args = p.parse_args()
destination = args.output.resolve()
if not destination.is_relative_to(ROOT / 'docs' / 'research' / 'assets' / 'phase-2'):
    raise RuntimeError('Evidence output must stay in the named research assets directory')
destination.mkdir(parents=True, exist_ok=True)
archive = destination / 'evidence.zip'
manifest = destination / 'manifest.json'
if archive.exists() or manifest.exists():
    raise RuntimeError('Do not overwrite an existing evidence archive')
allowed = {'.json', '.log', '.xml', '.png', '.py', '.ps1'}
records = {}
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for path in sorted(BASE.rglob('*')):
        relative = path.relative_to(BASE)
        if not path.is_file() or path.suffix.lower() not in allowed:
            continue
        if any(part in {'runtime', '__pycache__'} for part in relative.parts):
            continue
        if not path.resolve().is_relative_to(BASE):
            raise RuntimeError('Evidence path escapes its verification directory')
        content = path.read_bytes()
        name = relative.as_posix()
        records[name] = {'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}
        output.writestr(name, content)
with zipfile.ZipFile(archive) as check:
    if set(check.namelist()) != set(records):
        raise RuntimeError('Archive membership mismatch')
    for name, identity in records.items():
        content = check.read(name)
        if len(content) != identity['bytes'] or hashlib.sha256(content).hexdigest() != identity['sha256']:
            raise RuntimeError('Archive readback mismatch: ' + name)
record = {
    'source_commit': args.source_commit,
    'scope': 'D038/D039 Windows generated evidence, including earlier failures and exact per-run source/binary limits. No executable files, databases, real mailbox data or credentials.',
    'archive': {'file': archive.name, 'bytes': archive.stat().st_size,
                'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
    'artifact_count': len(records), 'uncompressed_bytes': sum(v['bytes'] for v in records.values()),
    'artifacts': records, 'readback_verified': True,
}
manifest.write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
print(json.dumps({key: value for key, value in record.items() if key != 'artifacts'}, indent=2))
