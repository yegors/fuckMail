import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT))
from scripts import dev
out=Path(__file__).parent
mode,attempt=sys.argv[1:3]
base=out/('gui-'+mode+'-'+attempt)
for suffix in ['.log','.source.json','.result.json']:
 if base.with_suffix(suffix).exists(): raise RuntimeError('Refuse existing numbered evidence')
paths=list((ROOT/'gui').glob('*'))+[ROOT/'CMakeLists.txt']
inputs=lambda:{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.is_file()}
before=inputs();base.with_suffix('.source.json').write_text(json.dumps(before,indent=2)+'\n')
env=dev.environment();env['QT_FORCE_STDERR_LOGGING']='1';build=ROOT/'build/p2-05b3a-gui-dev'
if mode in ['build','app-build']: command=[str(ROOT/'.tools/bootstrap/Lib/site-packages/cmake/data/bin/cmake.exe'),'--build',str(build),'--target','gui-calendar-controls-test','gui-calendar-occurrence-test','gui-mail-navigation-cache-test']+(['fuckmail-gui'] if mode=='app-build' else [])+['--parallel','2']
else:
 target={'controls':'gui-calendar-controls-test.exe','backend':'gui-calendar-occurrence-test.exe','cache':'gui-mail-navigation-cache-test.exe'}[mode]
 command=[str(build/target)]
 if mode=='controls' and len(sys.argv)>3:
  captures=out/sys.argv[3]
  if captures.exists(): raise RuntimeError('Refuse existing captures')
  env['FM_CALENDAR_CAPTURE_DIR']=str(captures)
start=time.monotonic()
with base.with_suffix('.log').open('x',encoding='utf-8') as log:
 result=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
after=inputs();changed=[p for p in before if before[p]!=after.get(p)]
report={'command':command,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'source_changes':changed,'source_count':len(before),'binary':None}
if mode not in ['build','app-build']:report['binary']={'path':command[0],'sha256':hashlib.sha256(Path(command[0]).read_bytes()).hexdigest()}
base.with_suffix('.result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report));print(base.with_suffix('.log').read_text(encoding='utf-8',errors='replace')[-6500:])
sys.exit(result.returncode)
