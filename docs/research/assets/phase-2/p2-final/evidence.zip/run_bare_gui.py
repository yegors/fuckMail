"""Observe ordinary packaged GUI startup without any app arguments."""
import ctypes
from contextlib import closing
import argparse
from ctypes import wintypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import dev

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--attempt", type=int, default=1)
args = parser.parse_args()
if not 1 <= args.attempt <= 99:
    parser.error("Use a bounded numbered attempt")
stem = f"package-bare-gui-{args.attempt:02}"
report_path = OUT / (stem + ".result.json")
log_path = OUT / (stem + ".log")
if report_path.exists() or log_path.exists():
    raise SystemExit("Refusing to replace a bare GUI attempt")
package = json.loads((OUT / "package-windows-01.result.json").read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


executables = package["executables"]
for record in executables.values():
    require(sha(Path(record["path"])) == record["sha256"], "Packaged executable differs from Package01")
gui = Path(executables["fuckmail-gui.exe"]["path"])
cli = Path(executables["fm.exe"]["path"])
scratch = Path(tempfile.mkdtemp(prefix="fuckmail-bare-gui-")).resolve()
temp_parent = Path(tempfile.gettempdir()).resolve()
require(scratch.parent == temp_parent and scratch.name.startswith("fuckmail-bare-gui-"), "Unexpected temporary directory")
profile = scratch / "user-data/fuckMail/default"
env = dev.package_environment()
env.pop("QT_QPA_PLATFORM", None)
env.pop("QT_QUICK_BACKEND", None)
env.pop("FM_PROFILE", None)
env["LOCALAPPDATA"] = str(scratch / "user-data")
(scratch / "user-data").mkdir()
user32 = ctypes.WinDLL("user32", use_last_error=True)
callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
user32.EnumWindows.argtypes = [callback_type, wintypes.LPARAM]
user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
user32.IsWindowVisible.argtypes = [wintypes.HWND]
user32.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]


def own_windows(pid):
    found = []
    @callback_type
    def visit(hwnd, unused):
        owner = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(owner))
        if owner.value == pid and user32.IsWindowVisible(hwnd):
            found.append(hwnd)
        return True
    require(user32.EnumWindows(visit, 0), "Unable to locate owned GUI window")
    return found


def discovery_pid():
    try:
        # Never retain or print the private IPC token.
        return int(json.loads((profile / "engine.json").read_text(encoding="utf-8"))["pid"])
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def wait_until(predicate, seconds, message):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        value = predicate()
        if value:
            return value
        time.sleep(0.05)
    raise RuntimeError(message)


started = time.monotonic()
child = None
engine_pid = None
result = {"status": "failed", "package_source_commit": package["source_commit"],
          "scope": "Ordinary packaged GUI with zero arguments, isolated temporary LOCALAPPDATA; no self-test/demo/profile flags or Google activity.",
          "executables": executables, "arguments": [], "fm_profile_absent": "FM_PROFILE" not in env}
try:
    with log_path.open("x", encoding="utf-8", newline="\n") as log:
        child = subprocess.Popen([str(gui)], cwd=gui.parent, env=env, stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT)
        def ready():
            require(child.poll() is None, "Bare GUI exited before startup")
            return (profile / "store.sqlite3").is_file() and discovery_pid() and own_windows(child.pid)
        windows = wait_until(ready, 20, "Bare GUI did not create its owned default store/window")
        engine_pid = discovery_pid()
        require(dev.engine_running(engine_pid), "GUI-created engine was not alive before CLI")
        with closing(sqlite3.connect((profile / "store.sqlite3").as_uri() + "?mode=ro", uri=True)) as db:
            db.execute("PRAGMA query_only=ON")
            metadata = dict(db.execute("SELECT key,value FROM meta WHERE key IN ('profile_kind','fixture_revision')"))
            counts = {table: db.execute("SELECT count(*) FROM " + table).fetchone()[0]
                      for table in ("accounts", "messages", "conversations", "drafts", "calendar_sources")}
            require(metadata == {"profile_kind": 1, "fixture_revision": 0} and all(value == 0 for value in counts.values()),
                    "GUI-created default contained synthetic or preexisting content")
        completed = subprocess.run([str(cli), "--json", "accounts"], cwd=cli.parent, env=env, stdin=subprocess.DEVNULL,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=15,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        require(completed.returncode == 0, "Packaged CLI could not query the GUI-owned default")
        reply = json.loads(completed.stdout)
        require(reply.get("ok") is True and reply["result"].get("accounts") == [] and reply["result"].get("fixture_revision") == 0,
                "CLI did not observe the same empty live default")
        deadline = time.monotonic() + 1.2
        while time.monotonic() < deadline:
            require(child.poll() is None and discovery_pid() == engine_pid and dev.engine_running(engine_pid),
                    "Engine did not remain owned by the GUI after CLI exit")
            time.sleep(0.05)
        require(not (scratch / "user-data/fuckMail/demo-v1").exists(), "Ordinary startup created demo-v1")
        windows = own_windows(child.pid)
        require(windows, "GUI main window disappeared before close")
        for window in windows:
            require(user32.PostMessageW(window, 0x0010, 0, 0), "Unable to request graceful owned-window close")
        require(child.wait(timeout=15) == 0, "Ordinary GUI did not exit successfully after WM_CLOSE")
        wait_until(lambda: not (profile / "engine.json").exists() and not dev.engine_running(engine_pid),
                   10, "GUI-owned engine remained after final close")
        result.update(status="passed", metadata=metadata, empty_table_counts=counts, cli_accounts=[], cli_fixture_revision=0,
                      store_created_before_cli=True, same_engine_held_after_cli=True, graceful_wm_close=True,
                      engine_stopped=True, no_demo_profile=True)
except Exception as exc:
    result["error"] = f"{type(exc).__name__}: {exc}"
finally:
    cleanup_ok = True
    if child is not None and child.poll() is None:
        try:
            for window in own_windows(child.pid):
                user32.PostMessageW(window, 0x0010, 0, 0)
            child.wait(timeout=10)
        except Exception:
            cleanup_ok = False
    if engine_pid is not None:
        try:
            wait_until(lambda: not dev.engine_running(engine_pid), 10, "Owned engine cleanup did not finish")
        except Exception:
            cleanup_ok = False
    if cleanup_ok:
        require(scratch.resolve() == scratch and scratch.parent == temp_parent and scratch.name.startswith("fuckmail-bare-gui-"),
                "Temporary cleanup target changed")
        try:
            shutil.rmtree(scratch)
        except Exception as exc:
            result.update(status="failed", cleanup_error=f"{type(exc).__name__}: {exc}", retained_temporary_profile=str(scratch))
    else:
        result.update(status="failed", retained_temporary_profile=str(scratch), cleanup_failed=True)
    result["elapsed_seconds"] = time.monotonic() - started
    result["temporary_profile_removed"] = not scratch.exists()
    result["log_sha256"] = sha(log_path) if log_path.exists() else None
    result["executables_unchanged"] = all(sha(Path(record["path"])) == record["sha256"] for record in executables.values())
    if not result["executables_unchanged"]:
        result["status"] = "failed"
    result["limitations"] = ["Generated empty-profile launch and graceful close only; no real login, mailbox import, physical-input, or performance acceptance."]
    report_path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result))
raise SystemExit(0 if result["status"] == "passed" else 1)
