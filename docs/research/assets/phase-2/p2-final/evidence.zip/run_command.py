import argparse, json, subprocess, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from scripts import dev
p = argparse.ArgumentParser()
p.add_argument('--name', required=True)
p.add_argument('--timeout', type=int, default=900)
p.add_argument('command', nargs=argparse.REMAINDER)
a = p.parse_args()
command = a.command[1:] if a.command[:1] == ['--'] else a.command
if not command: p.error('command required')
base = Path(__file__).parent / a.name
log = base.with_suffix('.log'); result = base.with_suffix('.result.json')
if log.exists() or result.exists(): raise RuntimeError('Use a new numbered run')
start = time.monotonic(); error = None; code = -1
with log.open('x', encoding='utf-8') as output:
    try:
        code = subprocess.run(command, cwd=ROOT, env=dev.environment(), stdin=subprocess.DEVNULL,
            stdout=output, stderr=subprocess.STDOUT, timeout=a.timeout).returncode
    except Exception as exc: error = str(exc)
report = {'command':command,'exit_code':code,'elapsed_seconds':time.monotonic()-start,'error':error}
result.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
print(json.dumps(report)); print(log.read_text(encoding='utf-8', errors='replace')[-7000:])
raise SystemExit(0 if code == 0 else 1)